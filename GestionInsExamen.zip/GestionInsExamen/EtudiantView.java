public class EtudiantView {
    public static void main(String[] args) throws Exception {
        int choix;
        Scanner sc=new Scanner(System.in);
        do{
            System.out.println("1-Faire une demande d'inscription");
            System.out.println("2-Faire une demande de réinscription");
            System.out.println("3-Quitter");
            choix=sc.nextInt();
            sc.nextLine();
            switch (choix) {
                case 1:
                    
                    break;
                case 2:

                    break;

                case 3:

                    break;
            
                default:
                    break;
            }
        }while(choix!=5);
    }

 }
