package repositories;

public class AttacheRepository extends Database{
    
}
