package entities;

public enum Niveau {
     L1, L2, L3
}
