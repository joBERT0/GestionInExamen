package entities;

public enum Filiere {
    GLRS,IAGE,ETSE,TTL,MAIE
}
