package entities;

public enum Grade {
    Docteur,Ingenieur,Assistant,Doyen
}
