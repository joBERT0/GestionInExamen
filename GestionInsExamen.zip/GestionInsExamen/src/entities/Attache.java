package entities;

public class Attache {
    
}
